`Update On : 2025.07.02`
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=ADD8E6&center=true&width=1000&height=200&lines=LARA-MD-BOT" alt="Typing SVG" /></a>
<div align="center">
	<h3>👧🏻LARA-MD WHATSAPP BOT👧🏻</h3>
<img src="https://i.ibb.co/Gfj3PWGG/20250224-022914.jpg" width="300" height="150">
</div>
<div align="center">
</p>
	
## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F00&lines=HELLO+IM+SADDESHA+LARA+MD+DEVELOPER)](https://git.io/typing-svg)

<hr>
<img src="https://readme-typing-svg.herokuapp.com?size=33&width=1000&lines=Welcome+To+Lara-MD...;Created+by+Sadeesha...;World+Best+Whatsapp+User+Bot...;Simple+Java+Script+Bot...;Simple+And+Fast+Deploy...;Thank+You+For+Using+Lara-MD..."
            alt="Typing">

<div align="center">
	<img src="https://moe-counter.glitch.me/get/@Anya_v2-Md?theme=gelbooru" width="300" height="150" alt="sadeesha">
</div>

<hr>

			Lara-MD බොට් යනු WhatsApp සඳහා වන පරිශීලක බොට් එකක් වන අතර එමඟින් ඔබට බොහෝ කාර්යයන් ඉටු කිරීමට ඉඩ සලසයි. මෙය විවෘත මූලාශ්‍ර ව්‍යාපෘතියක් නොවේ. මෙය බොට් යන්ත්‍රයක් යෙදවීමට ඔබට ඉඩ සලසන ව්‍යාපෘතියක් පමණි
       
<h3>🌸 How To Deploy </h3>

<h5>🌸 First tap to Fork button and create new fork</h5>

<h4>🌸 Following 👇</h4>
<hr>	
<h3>🌸 Get Your SESSION ID 👇</h3> 
<h4>Click the SESSION_ID Button</h4>
<h5>🌸(SESSION_ID ලබා ගැනීමට පහත බටන් click කරන්න)</h5> 
<h3>SEVER ➊</h3>
<div align="center">
<button><tr><a href="https://main-pair.onrender.com">🌸 SESSION_ID 🌸 ➊</a></tr></button>
<h3>SEVER ❷</h3>
<div align="center">
<button><tr><a href="https://lexical-anastasia-tharumin-0408c6c2.koyeb.app">🌸 SESSION_ID 🌸 ❷</a></tr></button>
</div>
<br>

*🌸 Now get your inbox and copy sessino id*

*🌸 If you past session id in (settings.js/SESSION_ID || "past_copy_text")*

<h3>🌸 Supported Group link </h3>
<a href="https://chat.whatsapp.com/Ci5mDk9zEVF95NcuqEtzl4">Join Lara suported 👧</a>
<hr>
<h3>🌸 Lara updates chanels </h3>
<a href="https://whatsapp.com/channel/0029VaD5t8S1nozDfDDjRj2J">Join Lara updates chanel 👧</a>
<hr>

***CLICK THE BUTTON BELOW TO DEPLOY🌸***

 <details close>
<summary>🌸 DEPLOY ONLY PAY 🌸</summary>
	 
--------	 
1.  #### DEPLOY IN HEROKU 

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/tharumin/Lara-3V)

--------
2.  #### DEPLOY IN REPLIT

   <a href='https://repl.it/github/GlobalTechInfo/SUHAIL-XMD' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------
3.  #### DEPLOY IN KOYEB

<a href='https://app.koyeb.com/auth/signin' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-KOYEB-blue?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

--------
4.  #### DEPLOY IN GLITCH

<a href='https://glitch.com/signup' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/GLITCH-h?color=pink&style=for-the-badge&logo=glitch'/></a></p>

--------

5.  #### DEPLOY TO CODESPACE

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

--------

6. #### DEPLOY TO RENDER

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

--------
7. #### DEPLOY TO RAILWAY

<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RAILWAY-h?color=black&style=for-the-badge&logo=railway'/></a></p>

--------
</details>
<details close>
<summary>🌸 DEPLOY IN FREE 🌸</summary>

<h5>🌸 Deploy Free Koyeb👇</h5>
<a href="http://koyeb.com" ><img src="https://i.ibb.co/t4KftP0/images.png width="50" height="25"></a>
<hr>
<h5>🌸 Deploy Free Workflows 👇</h5>

```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Start application
      run: npm start
```	
</details>
<hr>
<img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=Created+By+Sadeesha_Min" alt="">
<hr>

<h5>🌸 TOTAL WEB VIEWS</h5>
<img src="https://profile-counter.glitch.me/Sadeesha/count.svg" center>

<hr>

<div align="center">
<h3>🌸 LARA-MD DEVELOPER TEAM 👤</h3>

| SADEESHA 👤              | WISWAJITH 👤              |
|---------------------|---------------------|
[![Owner](https://i.ibb.co/63zDkQy/IMG-20250513-135909-02.jpg)](https://github.com/sadiyamin/) | [![Wiswajith](https://i.ibb.co/R4sCSLDw/IMG-20250618-WA0052.jpg)](https://github.com/sadiyamin/) |
</div>
<hr>

<hr>

<div align="center">
    
| Owner 👤             | Repo 🤖              | Forks 🍽️             | Stars 🌟            | Language 🗣️        | Licence 🪪              
|----------------------|----------------------|----------------------|---------------------|---------------------|---------------------|
| [![Owner](https://img.shields.io/badge/Author-sSadeesha-red.svg)](https://github.com/sadiyamin/Alexa/) | [![Repository](https://img.shields.io/badge/Repo-Alexa-red.svg)](https://github.com/sadiyamin/Alexa) | [![GitHub forks](https://badgen.net/github/forks/sadiyamin/Alexa/)](https://GitHub.com/sadiyamin/Alexa/network/) | [![GitHub stars](https://badgen.net/github/stars/sadiyamin/Alexa)](https://GitHub.com/sadiyamin/Alexa/stargazers/) | ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) | [![GitHub license](https://img.shields.io/github/license/PikaBotz/anya_v2-md.svg)](https://github.com/sadiyamin/Alexa/blob/master/LICENSE) 

| Version 💻              | Last Commit 💫              | Maintained 🤌🏻             |
|---------------------|---------------------|---------------------|
| [![GitHub release](https://img.shields.io/github/release/sadiyamin/Alexa.svg)](https://GitHub.com/sadiyamin/Alexa/releases/) | [![GitHub latest commit](https://badgen.net/github/last-commit/sadiyamin/Alexa)](https://GitHub.com/sadiyamin/Alexa/commit/) | [![Maintenance](https://img.shields.io/badge/maintained%3F-yes-green.svg)](https://GitHub.com/sadiyamin/Alexa/graphs/commit-activity) |


</div>

<h5>Thank You For Using Lara-MD 💗</h5>

<hr>

<h3>⚠️ Warning!</h3>

<h5>Because of user bots; Your WhatsApp account can be banned. You are responsible for everything you do. Most likely, using WhatsApp setting management commands too much may caused getting banned. Certainly, Lara-MD executives do not take responsibility. By setting up Lara-MD Bot you are considered to have assumed these responsibilities.</h5>
<hr>
